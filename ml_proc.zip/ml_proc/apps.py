from django.apps import AppConfig


class MlProcConfig(AppConfig):
    name = 'ml_proc'
