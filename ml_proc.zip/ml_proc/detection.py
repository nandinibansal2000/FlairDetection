import praw
import prawcore
import pickle
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from urllib.parse import urlparse
import pandas as pd
import sklearn
import pickle
import praw
import re
from bs4 import BeautifulSoup
import nltk
from nltk.corpus import stopwords
from urllib.parse import urlparse
reddit = praw.Reddit(client_id='#',
                     client_secret='#',
                     password='#',
                     user_agent='#',
                     username='#')

USER_AGENT = 'Flair Script For Reddit by /u/nandini18056'
from sklearn.externals import joblib
mj=joblib.load('model_joblib')

DIGITS=[0,1,2,3,4,5,6,7,8,9]
SYMBOLS=['*','/','-','(',')',';','#','/','{','}','|','+','.','?','&','$',"@","%",'^','=']
STOPWORDS = set(stopwords.words('english'))

url=input()

def cleaning(df):
   
	
	try:
		
		df = df.lower()
		
		df = ' '.join(word for word in df.split() if word not in SYMBOLS)
		df = ' '.join(word for word in df.split() if word not in DIGITS)
		df = ' '.join(word for word in df.split() if word not in STOPWORDS)
		return df
	except:
		return "null"

D = reddit.submission(url=url)
parse_object = urlparse(D.url)


# submission.comments.replace_more(limit=None)
s = ''
for top_level_comment in D.comments:
	s = s + ' ' + top_level_comment.body

dict1 = {}

dict1['title'] = D.title

parse_object = urlparse(D.url)
dict1['netloc']=parse_object.netloc
dict1['path']=parse_object.path
# submission.comments.replace_more(limit=None)

dict1["comment"] = s
dict1['title'] = cleaning(dict1['title'])
dict1['comment'] = cleaning(dict1['comment'])
dict1['path'] = cleaning(dict1['path'])
dict1['combine'] = dict1['title'] + dict1['comment'] + dict1['netloc']+dict1['path']
print(mj.predict([dict1['combine']]))