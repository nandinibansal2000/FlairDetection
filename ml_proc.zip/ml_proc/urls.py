from django.conf.urls import url
import ml_proc.views as views

urlpatterns = [
    url(r'^$' , views.input_page , name = 'input page'),
]
